import javax.swing.JFrame;


public class windowView
{
	public static void main(String[] args)
	{
		JFrame frame = new window();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}
}