import java.util.ArrayList;
import java.util.Arrays;

public class quickSort
{
	public static void main(String[] args)
	{
    StopWatch t = new StopWatch();

    int[] a1 = ArrayUtil.randomIntArray(10000,100);
    int[] a2 = ArrayUtil.randomIntArray(20000,100);
    int[] a3 = ArrayUtil.randomIntArray(30000,100);
    int[] a4 = ArrayUtil.randomIntArray(40000,100);
    int[] a5 = ArrayUtil.randomIntArray(50000,100);
    int[] a6 = ArrayUtil.randomIntArray(60000,100);

    t.start();
    qsort(a1, 0, a1.length -1 );
    t.stop();
    System.out.println("Length: "+ a1.length + "| T = " + t.getElapsedTime()+ "ms");
    t.reset();

    t.start();
    qsort(a2, 0, a2.length -1 );
    t.stop();
    System.out.println("Length: "+ a2.length + "| T = " + t.getElapsedTime()+ "ms");
    t.reset();

    t.start();
    qsort(a3, 0, a3.length -1 );
    t.stop();
    System.out.println("Length: "+ a3.length + "| T = " + t.getElapsedTime()+ "ms");
    t.reset();

    t.start();
    qsort(a4, 0, a4.length -1 );
    t.stop();
    System.out.println("Length: "+ a4.length + "| T = " + t.getElapsedTime()+ "ms");
    t.reset();

    t.start();
    qsort(a5, 0, a5.length -1 );
    t.stop();
    System.out.println("Length: "+ a5.length + "| T = " + t.getElapsedTime()+ "ms");
    t.reset();

    t.start();
    qsort(a6, 0, a6.length -1 );
    t.stop();
    System.out.println("Length: "+ a6.length + "| T = " + t.getElapsedTime()+ "ms");
    t.reset();
	}

   public static void qsort(int[] a, int start, int end)
   {
     if(start < end)
     {
         int pIndex=partition(a, start, end);
         qsort(a,start, pIndex-1);
         qsort(a,pIndex+1, end);

    }
  }

  public static int partition(int[] b, int start, int end)
  {
    int pivot=b[end];
    int pindex=start;

    for(int i=start; i<end ; i++)
    {
      if(b[i] <= pivot)
      {
       int temp=b[i];
       b[i]=b[pindex];
       b[pindex]=temp;
       pindex++;
      }

    }
     int temp=b[pindex];
     b[pindex]=b[end];
     b[end]=temp;

     return pindex;
    }


}
