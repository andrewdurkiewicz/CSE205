import javax.swing.JFrame;
public class MyCustomFrameViewer
{
	public static void main(String[] args)
	{
		MyCustomFrame frame = new MyCustomFrame();
		frame.setVisible(true);
	}
} 